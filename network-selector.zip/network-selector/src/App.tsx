import NetworkSelector from "./components/NetworkSelector";

function App() {
  return <NetworkSelector />;
}

export default App;
